# 小米 NAS 录播入口 · Docker 网页代理版 0.2.0

统一使用已有 fullstack Docker 在 3000 端口提供的网页。插件没有独立的观看首页、日历、播放器或前端构建产物；Docker 更新网页后，重新打开插件即可使用新网页。

```text
NAS App 的插件入口壳
  → iframe 打开 /plugin/<UID>/bililivewatch/web/index.html#/mobile
  → NAS Nginx 转发到 http://127.0.0.1:3000/index.html
  → 页面脚本、CSS、接口、视频均实时来自现有 Docker
```

插件壳只负责承载原网页，避免 NAS 宿主样式干扰。代理给原 HTML 注入一个小型存储适配脚本，并把返回 JavaScript 中的默认 API 地址 `/api` 替换成插件前缀；不修改容器里的文件或业务逻辑。

- [部署与回滚手册](部署手册.md) / [离线 HTML 手册](部署手册.html)
- [设计与测试说明](开发说明.md) / [测试报告](测试报告.md)
- 检查：`sh deploy/check.sh --uid 你的数字UID`
- 部署：`sh deploy/deploy.sh --uid 你的数字UID`
- 回滚：`sh /data/bililive-nas-plugin/runtime/rollback.sh`

默认 upstream 为 `http://127.0.0.1:3000`，可通过 `--upstream http://127.0.0.1:实际端口` 设置。

NAS 的 Nginx 必须包含 `http_sub_module`；缺少时检查脚本直接停止，不会修改配置或自动安装系统软件。NAS 上不需要 Node.js、前端编译或新增 HTTP 服务。

如果已安装上一版 0.1.0，先使用原回滚脚本卸载，再部署本版。录像、Docker 配置和观看进度都会保留。

本包仅本地交付，不提交 GitHub。真实小米 NAS、官方 App 和移动网络视频通道仍须按手册验收。
