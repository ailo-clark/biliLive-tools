#!/usr/bin/python3
"""Static UI only, reached after the NAS plugin.cgi login check."""
import mimetypes
import os
from pathlib import Path
import sys


def serve(root, requested, output):
    root = Path(root).resolve()
    try:
        target = Path(requested).resolve(strict=True)
        target.relative_to(root)
        if not target.is_file() or target.suffix not in {".html", ".js", ".css", ".json", ".png", ".jpg", ".jpeg", ".svg", ".ico", ".woff", ".woff2", ".ttf", ".wasm"}:
            raise ValueError("not a UI file")
    except (ValueError, OSError):
        output.write(b"Status: 404 Not Found\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nNot found")
        return
    mime = {".js": "application/javascript", ".wasm": "application/wasm"}.get(target.suffix) or mimetypes.guess_type(target)[0] or "application/octet-stream"
    # index/shell use no-cache; hashed Vite assets can be cached privately.
    cache = "private, max-age=86400" if "assets" in target.relative_to(root).parts else "no-cache"
    output.write(f"Content-Type: {mime}\r\nContent-Length: {target.stat().st_size}\r\nCache-Control: {cache}\r\nX-Content-Type-Options: nosniff\r\n\r\n".encode())
    if os.environ.get("REQUEST_METHOD", "GET") == "HEAD":
        return
    with target.open("rb") as stream:
        while data := stream.read(64 * 1024):
            output.write(data)


if __name__ == "__main__":
    serve(Path(__file__).parent, os.environ.get("FILE_REQ", ""), sys.stdout.buffer)
