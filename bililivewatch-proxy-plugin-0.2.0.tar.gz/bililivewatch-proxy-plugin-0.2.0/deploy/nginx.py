"""Proxy the live Docker UI and its APIs under a NAS plugin URL."""
import re
from urllib.parse import urlsplit

PLUGIN = "bililivewatch"


def validate_upstream(value):
    parsed = urlsplit(value)
    if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or not parsed.port
            or parsed.path not in ("", "/") or parsed.query or parsed.fragment
            or parsed.username or parsed.password or not 1 <= parsed.port <= 65535):
        raise ValueError("upstream 必须是 http://127.0.0.1:端口，指向现有 fullstack 容器")
    return f"http://127.0.0.1:{parsed.port}", parsed.port


def markers(uid):
    return f"# BEGIN bililivewatch uid={uid}\n", f"# END bililivewatch uid={uid}\n"


def render(uid, upstream):
    if not re.fullmatch(r"[1-9][0-9]{0,19}", str(uid)):
        raise ValueError("UID 必须为不带 u 前缀的正整数")
    upstream, _ = validate_upstream(upstream)
    # Both URL forms are accepted; generated links use the canonical numeric UID.
    route = rf"/plugin/u?{uid}/{PLUGIN}"
    public = f"/plugin/{uid}/{PLUGIN}"
    def proxy(rewrite):
        return f"""
    if ($need_reject) {{ return 403; }}
    {rewrite}
    proxy_pass {upstream};
    proxy_http_version 1.1;
    proxy_set_header Host $proxy_host;
    proxy_set_header Authorization $http_authorization;
    proxy_set_header Cookie "";
    proxy_set_header Accept-Encoding "";
    set $bililivewatch_connection "";
    if ($http_upgrade != "") {{ set $bililivewatch_connection "upgrade"; }}
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection $bililivewatch_connection;
    proxy_set_header X-Forwarded-Proto https;
    proxy_buffering off;
    proxy_request_buffering off;
    proxy_max_temp_file_size 0;
    proxy_connect_timeout 5s;
    proxy_read_timeout 3600s;
    client_max_body_size 0;
    access_log off;
    proxy_hide_header ETag;
    proxy_hide_header Last-Modified;
    add_header Cache-Control "no-store" always;
"""
    start, end = markers(uid)
    api = proxy(f"rewrite ^{route}/api(.*)$ /api$1 break;")
    web = proxy(f"rewrite ^{route}/web/(.*)$ /$1 break;") + """
    proxy_set_header If-None-Match "";
    proxy_set_header If-Modified-Since "";
    proxy_set_header Range "";
    proxy_set_header If-Range "";
"""
    return start + f"""# The original Docker API, including streaming, SSE and WebSocket upgrades.
location ~ "^{route}/api(?:/|$)" {{{api}}}

# Only the HTML entry gets the NAS storage adapter. No copied business UI.
location ~ "^{route}/web/(?:index\\.html)?$" {{{web}
    sub_filter '<head>' '<head><script src="{public}/bridge.js?v=0.2.0"></script>';
    sub_filter_once on;
}}

# Change only the literal default API base in live JavaScript responses.
# Module/chunk URLs and all business logic continue to come from Docker.
location ~ "^{route}/web/.*\\.js$" {{{web}
    sub_filter_types application/javascript text/javascript;
    sub_filter '"/api"' '"{public}/api"';
    sub_filter "'/api'" "'{public}/api'";
    sub_filter '`/api`' '`{public}/api`';
    sub_filter_once off;
}}

# CSS, images, fonts and other unmodified resources.
location ~ "^{route}/web/" {{{web}}}
""" + end


def remove_block(content, uid, expected):
    start, end = markers(uid)
    if start not in content and end not in content:
        return content
    if content.count(start) != 1 or content.count(end) != 1 or content.count(expected) != 1:
        raise RuntimeError("插件 Nginx 配置被修改，已停止回滚；请先检查备份和当前配置")
    return content.replace(expected, "", 1)
