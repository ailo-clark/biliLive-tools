// NAS embedding adapter only. The application HTML/JS/CSS are served by Docker.
(function () {
  "use strict";
  var match = location.pathname.match(
    /\/plugin\/u?(\d+)\/bililivewatch\/web\//,
  );
  if (!match) return;
  var uid = match[1];
  var api = "/plugin/" + uid + "/bililivewatch/api";
  var prefix = "bililivewatch:" + uid + ":";
  var raw = window.localStorage;
  function keys() {
    return Object.keys(raw).filter(function (key) {
      return key.indexOf(prefix) === 0;
    });
  }
  var scoped = {
    getItem: function (key) {
      var value = raw.getItem(prefix + String(key));
      // Existing plugin login data may have used another accepted UID form.
      return key === "api" && value !== null ? api : value;
    },
    setItem: function (key, value) {
      raw.setItem(prefix + String(key), key === "api" ? api : String(value));
    },
    removeItem: function (key) {
      raw.removeItem(prefix + String(key));
    },
    clear: function () {
      keys().forEach(function (key) {
        raw.removeItem(key);
      });
    },
    key: function (index) {
      var key = keys()[index];
      return key ? key.slice(prefix.length) : null;
    },
  };
  Object.defineProperty(scoped, "length", {
    get: function () {
      return keys().length;
    },
  });
  Object.defineProperty(window, "localStorage", {
    configurable: true,
    value: scoped,
  });
  // Start on the watch view; the original "电脑版" control remains available.
  if (scoped.getItem("view-mode") === null)
    scoped.setItem("view-mode", "mobile");
  window.__bililiveNasProxy = {
    version: "0.2.0",
    api: api,
    storagePrefix: prefix,
  };
})();
