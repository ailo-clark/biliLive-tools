(function () {
  "use strict";
  var root = document.getElementById("bililivewatch-shell");
  if (!root) return;
  var script = document.currentScript;
  var paths = [window.location.pathname, script && script.src];
  var match = paths
    .map(function (p) {
      return String(p || "").match(/\/plugin\/(u?\d+)\/bililivewatch(?=\/|$)/);
    })
    .find(Boolean);
  if (!match) {
    root.textContent =
      "未能识别 NAS 插件地址。请从 NAS App 的“录播观看”图标打开。";
    return;
  }
  if (root.querySelector("iframe")) return;
  root.textContent = "";
  var frame = document.createElement("iframe");
  frame.title = "录播观看";
  frame.setAttribute("allow", "autoplay; fullscreen; picture-in-picture");
  frame.setAttribute("allowfullscreen", "");
  frame.style.cssText =
    "display:block;width:100%;height:100%;border:0;background:#fff";
  frame.src = "/plugin/" + match[1] + "/bililivewatch/web/index.html#/mobile";
  root.appendChild(frame);
  var observer;
  function fit() {
    var host = root.closest("micro-app");
    var top = root.getBoundingClientRect().top;
    var available = host
      ? host.getBoundingClientRect().bottom - top
      : window.innerHeight - top;
    if (!Number.isFinite(available) || available < 260)
      available = window.innerHeight - top;
    root.style.height = Math.max(260, available) + "px";
  }
  fit();
  window.addEventListener("resize", fit);
  if (typeof ResizeObserver === "function") {
    observer = new ResizeObserver(fit);
    observer.observe(root.parentElement || root);
  }
  function dispose() {
    window.removeEventListener("resize", fit);
    window.removeEventListener("unmount", dispose);
    window.removeEventListener("pagehide", dispose);
    if (observer) observer.disconnect();
    // Give the iframe's progress hook a chance to enqueue its keepalive write
    // before the NAS removes its window (DOM removal alone may omit pagehide).
    try {
      frame.contentWindow.dispatchEvent(
        new frame.contentWindow.Event("pagehide"),
      );
    } catch (e) {}
    // Removing the document stops media and releases player resources.
    frame.remove();
  }
  window.addEventListener("unmount", dispose);
  window.addEventListener("pagehide", dispose);
})();
