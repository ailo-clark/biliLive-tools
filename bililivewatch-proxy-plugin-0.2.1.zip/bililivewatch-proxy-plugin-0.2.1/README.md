# 小米 NAS 录播入口 · Docker 网页代理版 0.2.1

统一使用已有 fullstack Docker 在 3000 端口提供的网页。插件没有独立的观看首页、日历、播放器或前端构建产物；Docker 更新网页后，重新打开插件即可使用新网页。

```text
NAS App 的插件入口壳
  → iframe 打开 /plugin/<UID>/bililivewatch/web/index.html#/mobile
  → NAS 已有 plugin.cgi 调用插件 Python 入口，实时读取 Docker HTML/JS
  → API、视频、CSS 等由 NAS Nginx 直接转发到 127.0.0.1:3000
  → 页面脚本、CSS、接口、视频均实时来自现有 Docker
```

插件壳只负责承载原网页，避免 NAS 宿主样式干扰。代理给原 HTML 注入一个小型存储适配脚本，并把返回 JavaScript 中的默认 API 地址 `/api` 替换成插件前缀；不修改容器里的文件或业务逻辑。

- [部署与回滚手册](部署手册.md) / [离线 HTML 手册](部署手册.html)
- [设计与测试说明](开发说明.md) / [测试报告](测试报告.md)
- 检查：`sh deploy/check.sh --uid 你的数字UID`
- 部署：`sh deploy/deploy.sh --uid 你的数字UID`
- 回滚：`sh /data/bililive-nas-plugin/runtime/rollback.sh`

默认 upstream 为 `http://127.0.0.1:3000`，可通过 `--upstream http://127.0.0.1:实际端口` 设置。

0.2.1 修复了 NAS Nginx 缺少 `http_sub_module` 时无法部署的问题。HTML/JS 的适配改由插件已有的 Python CGI 入口完成，不需要这个模块、不替换系统 Nginx、不新增常驻 HTTP 服务。视频与 API 仍由 Nginx 直接转发，不经过 Python。

如果 0.2.0 仅报模块缺失且提示未修改配置，直接解压本版检查和部署，无需回滚。已成功安装 0.1.0/0.2.0 的用户先使用原回滚脚本卸载，再部署本版。录像、Docker 配置和观看进度都会保留。

按用户授权仅向 GitHub 独立下载分支上传压缩包和文档，不提交解压后的插件源码。真实小米 NAS、官方 App 和移动网络视频通道仍须按手册验收。
