# 许可证与来源

本插件适配代码沿用上一版本的 GPL-3.0 许可证，见 LICENSE。

运行时使用用户已有 Docker 提供的 biliLive-tools 网页。本包不分发其网页脚本、播放器、前端构建产物或源代码归档。

- biliLive-tools：https://github.com/renmu123/biliLive-tools
- 用户分支：https://github.com/ailo-clark/biliLive-tools
- 本地验证基线：e68777b9e5fcbc2bd4ac2d3c7ddf4032996f2ef5
- NAS 插件机制参考：https://github.com/lvmaple/minas_plugin ，研究版本 843110ee8d93e385d889d04b84428d7e76f33be1

没有复制 Motrix 的网页、美术资源、Operator token 或 Python API 代理。本包不是小米官方签名插件。
