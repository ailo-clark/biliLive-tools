import base64
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deploy"))
from manage import Manager, PLUGIN, SHARED, UNIT, System, verify_package
from nginx import render, remove_block, validate_upstream
from static_cgi import serve


class FakeSystem:
    def __init__(self):
        self.events = []
        self.fail_test_once = False
        self.fail_reload_once = False
        self.fail_enable_once = False
        self.enabled = False

    def preflight(self, upstream):
        self.events.append("preflight")

    def nginx_test(self):
        self.events.append("test")
        if self.fail_test_once:
            self.fail_test_once = False
            raise RuntimeError("simulated invalid nginx config")

    def nginx_reload(self):
        self.events.append("reload")
        if self.fail_reload_once:
            self.fail_reload_once = False
            raise RuntimeError("simulated nginx reload failure")

    def daemon_reload(self):
        self.events.append("daemon-reload")

    def enable(self):
        self.events.append("enable")
        self.enabled = True
        if self.fail_enable_once:
            self.fail_enable_once = False
            raise RuntimeError("simulated partial systemctl enable failure")

    def disable(self):
        self.events.append("disable")
        self.enabled = False


class Deployment(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.system = FakeSystem()
        self.manager = Manager(self.root, self.system)
        self.uid = "12345"
        self.baseline = {
            "/etc/nginx/conf.d/luci/plugincenter.conf": b"# original\nlocation /plugin { return 200; }\n",
            "/data/plugin/u12345.list": b'{"existing":{"info":{"id":99},"custom":"preserve"}}\n',
            SHARED[0]: b'{"ports":{"reserve":true,"existing":{"u12345":9301}},"extra":17}\n',
            SHARED[1]: b'{"ports":{"reserve":true},"overlay":true}\n',
            "/original-data/app.db": b"original-db-do-not-touch\x00",
            "/original-data/watch-history.db": b"watch-progress-do-not-touch\x00",
            "/original-video/live.mp4": b"video-do-not-touch\x00",
        }
        for logical, data in self.baseline.items():
            path = self.manager.path(logical)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            path.chmod(0o640)
        self.manager.path("/tmp").mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def install(self):
        return self.manager.install(self.uid, "http://127.0.0.1:3000", ROOT)

    def assert_original(self):
        for logical, data in self.baseline.items():
            self.assertEqual(self.manager.path(logical).read_bytes(), data, logical)
            self.assertEqual(stat.S_IMODE(self.manager.path(logical).stat().st_mode), 0o640, logical)
        state = self.manager.load()
        for logical in state["owned"]:
            self.assertFalse(os.path.lexists(self.manager.path(logical)), logical)
        self.assertFalse(self.system.enabled)

    def test_check_does_not_modify_configuration(self):
        self.manager.inspect(self.uid, "http://127.0.0.1:3000", ROOT)
        self.assertFalse(self.manager.base.exists())
        for logical, data in self.baseline.items():
            self.assertEqual(self.manager.path(logical).read_bytes(), data)

    def test_install_and_byte_exact_rollback(self):
        state = self.install()
        self.assertEqual(state["status"], "installed")
        link = self.manager.path(state["owned"][1])
        self.assertTrue(link.is_symlink())
        self.assertEqual(link.resolve(), self.manager.path(state["home"]) / "src/ui")
        self.assertTrue((link / "bridge.js").exists())
        self.assertFalse((link / "web").exists())
        self.assertEqual(json.loads((link.resolve().parent / "proxy.json").read_text()), {"uid": self.uid, "port": 3000})
        self.assertEqual(stat.S_IMODE(self.manager.base.stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE(self.manager.manifest.stat().st_mode), 0o600)
        self.assertEqual(self.manager.rollback()["status"], "rolled_back")
        self.assert_original()

    def test_nginx_validation_failure_auto_rolls_back(self):
        self.system.fail_test_once = True
        with self.assertRaisesRegex(RuntimeError, "invalid nginx"):
            self.install()
        self.assertEqual(self.manager.load()["status"], "rolled_back")
        self.assert_original()

    def test_nginx_reload_failure_auto_rolls_back(self):
        self.system.fail_reload_once = True
        with self.assertRaisesRegex(RuntimeError, "reload failure"):
            self.install()
        self.assert_original()

    def test_partial_systemctl_enable_auto_rolls_back(self):
        self.system.fail_enable_once = True
        with self.assertRaisesRegex(RuntimeError, "partial systemctl"):
            self.install()
        self.assert_original()

    def test_existing_other_plugin_changes_survive_rollback(self):
        state = self.install()
        for logical in [state["list_path"], *SHARED]:
            path = self.manager.path(logical)
            data = json.loads(path.read_text())
            data["new-user-setting"] = {"keep": True}
            path.write_text(json.dumps(data))
        nginx = self.manager.path(state["nginx_path"])
        nginx.write_text(nginx.read_text() + "# another plugin added later\n")
        self.manager.rollback()
        for logical in [state["list_path"], *SHARED]:
            data = json.loads(self.manager.path(logical).read_text())
            self.assertTrue(data["new-user-setting"]["keep"])
            self.assertNotIn(PLUGIN, data if logical == state["list_path"] else data["ports"])
        self.assertTrue(nginx.read_text().endswith("# another plugin added later\n"))

    def test_runtime_status_changes_allow_rollback(self):
        state = self.install()
        path = self.manager.path(state["list_path"])
        data = json.loads(path.read_text())
        data[PLUGIN].update(status="stopped", enable=False, changetime=123)
        data[PLUGIN]["info"]["timestamp"] = 456
        path.write_text(json.dumps(data))
        self.manager.rollback()
        self.assert_original()

    def test_edited_plugin_config_stops_rollback_before_any_write(self):
        state = self.install()
        path = self.manager.path(state["list_path"])
        data = json.loads(path.read_text())
        data[PLUGIN]["frontend"]["title"] = "user changed"
        path.write_text(json.dumps(data))
        old_nginx = self.manager.path(state["nginx_path"]).read_bytes()
        with self.assertRaisesRegex(RuntimeError, "被修改"):
            self.manager.rollback()
        self.assertEqual(self.manager.path(state["nginx_path"]).read_bytes(), old_nginx)
        self.assertTrue(self.system.enabled)

    def test_modified_nginx_block_stops_rollback(self):
        state = self.install()
        path = self.manager.path(state["nginx_path"])
        path.write_text(path.read_text().replace("3600s", "30s"))
        with self.assertRaisesRegex(RuntimeError, "被修改"):
            self.manager.rollback()

    def test_bad_backup_hash_stops_rollback(self):
        state = self.install()
        state["snapshots"][SHARED[0]]["data"] = base64.b64encode(b"tampered").decode()
        self.manager.save(state)
        with self.assertRaisesRegex(RuntimeError, "备份校验失败"):
            self.manager.rollback()

    def test_rollback_failure_preserves_installed_configuration(self):
        state = self.install()
        before = {logical: self.manager.path(logical).read_bytes() for logical in state["snapshots"]}
        self.system.fail_test_once = True
        with self.assertRaises(RuntimeError):
            self.manager.rollback()
        self.assertEqual(self.manager.load()["status"], "recovery_needed")
        for logical, data in before.items():
            self.assertEqual(self.manager.path(logical).read_bytes(), data)
        self.manager.rollback()
        self.assert_original()

    def test_rollback_is_repeatable(self):
        self.install()
        self.manager.rollback()
        event_count = len(self.system.events)
        self.manager.rollback()
        self.assertEqual(len(self.system.events), event_count)
        self.assert_original()

    def test_second_install_is_rejected_without_overwrite(self):
        state = self.install()
        before = self.manager.path(state["nginx_path"]).read_bytes()
        with self.assertRaisesRegex(RuntimeError, "已有部署"):
            self.install()
        self.assertEqual(self.manager.path(state["nginx_path"]).read_bytes(), before)

    def test_reinstall_after_rollback_keeps_previous_backup(self):
        old = self.install()
        self.manager.rollback()
        new = self.install()
        self.assertNotEqual(old["backup_id"], new["backup_id"])
        self.assertTrue(self.manager.path(old["backup"]).exists())
        self.manager.rollback()
        self.assert_original()

    def test_boot_restore_then_rollback(self):
        state = self.install()
        shutil.rmtree(self.manager.path(state["home"]))
        self.manager.path(state["owned"][1]).unlink()
        self.manager.path(state["owned"][2]).unlink()
        self.manager.path(state["list_path"]).write_bytes(self.baseline[state["list_path"]])
        self.manager.path(state["nginx_path"]).write_bytes(self.baseline[state["nginx_path"]])
        self.manager.restore()
        self.assertTrue(self.manager.path(state["home"] + "/src/ui/bridge.js").exists())
        self.assertEqual(json.loads(self.manager.path(state["home"] + "/src/proxy.json").read_text()), {"uid": self.uid, "port": 3000})
        self.assertIn(PLUGIN, json.loads(self.manager.path(state["list_path"]).read_text()))
        self.assertIn(state["nginx_block"], self.manager.path(state["nginx_path"]).read_text())
        self.manager.rollback()
        self.assert_original()

    def test_boot_after_rollback_does_not_recreate_plugin(self):
        self.install()
        self.manager.rollback()
        self.manager.restore()
        self.assert_original()

    def test_missing_initial_list_removed_on_rollback(self):
        logical = "/data/plugin/u12345.list"
        self.manager.path(logical).unlink()
        self.baseline.pop(logical)
        self.install()
        self.manager.rollback()
        self.assertFalse(self.manager.path(logical).exists())
        self.assert_original()

    def test_absent_overlay_config_is_not_created(self):
        self.manager.path(SHARED[1]).unlink()
        self.baseline.pop(SHARED[1])
        self.install()
        self.assertFalse(self.manager.path(SHARED[1]).exists())
        self.manager.rollback()
        self.assert_original()

    def test_uid_and_upstream_input_rejected(self):
        for uid in ("", "u123", "../123", "123;touch /tmp/x", "0"):
            with self.subTest(uid=uid), self.assertRaises(ValueError):
                self.manager.inspect(uid, "http://127.0.0.1:3000", ROOT)
        for upstream in ("http://example.com:3000", "https://127.0.0.1:3000", "http://u:p@127.0.0.1:3000", "http://127.0.0.1:3000/api", "http://127.0.0.1:3000?x=1", "http://127.0.0.1:70000"):
            with self.subTest(upstream=upstream), self.assertRaises(ValueError):
                validate_upstream(upstream)

    def test_existing_plugin_directory_is_not_overwritten(self):
        path = self.manager.path("/home/u12345/plugin/" + PLUGIN)
        path.mkdir(parents=True)
        with self.assertRaisesRegex(RuntimeError, "目标已存在"):
            self.install()

    def test_existing_numeric_id_is_not_overwritten(self):
        path = self.manager.path("/data/plugin/u12345.list")
        path.write_text('{"another":{"info":{"id":108}}}')
        with self.assertRaisesRegex(RuntimeError, "108 已占用"):
            self.install()

    def test_symlink_config_is_not_followed(self):
        path = self.manager.path(SHARED[0])
        original = self.root / "private"
        path.rename(original)
        path.symlink_to(original)
        with self.assertRaisesRegex(RuntimeError, "不是普通文件"):
            self.install()
        self.assertEqual(original.read_bytes(), self.baseline[SHARED[0]])

    def test_nginx_prefix_caret_modifier_is_rejected(self):
        path = self.manager.path("/etc/nginx/conf.d/luci/plugincenter.conf")
        path.write_text("location ^~ /plugin { return 403; }\n")
        with self.assertRaisesRegex(RuntimeError, r"\^~"):
            self.install()

    def test_unrecognized_state_directory_is_not_overwritten(self):
        self.manager.base.mkdir(parents=True)
        (self.manager.base / "keep.txt").write_text("user file")
        with self.assertRaisesRegex(RuntimeError, "缺少部署记录"):
            self.install()
        self.assertEqual((self.manager.base / "keep.txt").read_text(), "user file")

    def test_recovery_journal_can_replace_damaged_state(self):
        state = self.install()
        recovery = self.manager.path(state["backup"]) / "deployment.json"
        self.assertEqual(json.loads(recovery.read_text()), self.manager.load())
        self.manager.manifest.write_text("damaged")
        shutil.copyfile(recovery, self.manager.manifest)
        self.manager.rollback()
        self.assert_original()
        self.assertEqual(json.loads(recovery.read_text())["status"], "rolled_back")

    def test_real_nginx_validates_installed_and_rolled_back_files(self):
        binary = os.environ.get("NGINX_BIN") or shutil.which("nginx") or "/workspace/cloud-setup/tools/nginx-proxy/sbin/nginx"
        if not Path(binary).is_file():
            self.skipTest("nginx binary is unavailable")
        (self.root / "logs").mkdir()
        config = self.root / "nginx.conf"
        config.write_text(f"pid {self.root}/nginx.pid;\nerror_log {self.root}/nginx.log;\nevents {{}}\nhttp {{ server {{ listen 127.0.0.1:18045; set $need_reject 1; include {self.manager.path('/etc/nginx/conf.d/luci/plugincenter.conf')}; }} }}\n")
        old = self.system.nginx_test
        def nginx_test():
            old()
            result = subprocess.run([binary, "-p", str(self.root) + "/", "-c", str(config), "-t"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
        self.system.nginx_test = nginx_test
        self.install()
        self.manager.rollback()
        self.assert_original()


class PackageIntegrity(unittest.TestCase):
    def test_detects_changed_file(self):
        import hashlib
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "file.txt").write_bytes(b"original")
            (root / "MANIFEST.json").write_text(json.dumps({"files": {"file.txt": hashlib.sha256(b"original").hexdigest()}}))
            verify_package(root)
            (root / "file.txt").write_bytes(b"modified")
            with self.assertRaisesRegex(RuntimeError, "校验失败"):
                verify_package(root)

    def test_rejects_manifest_path_escape(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "MANIFEST.json").write_text(json.dumps({"files": {"../outside": "invalid"}}))
            with self.assertRaisesRegex(RuntimeError, "路径异常"):
                verify_package(root)


class ProxyPreflight(unittest.TestCase):
    def fake_system(self, with_sub):
        from types import SimpleNamespace
        class Probe(System):
            def run(self, args, ok=(0,)):
                if args[1] == "-T":
                    return SimpleNamespace(stdout="plugincenter.conf $need_reject", stderr="", returncode=0)
                return SimpleNamespace(stdout="", stderr="--with-http_sub_module" if with_sub else "", returncode=0)
        return Probe()

    def test_missing_sub_module_no_longer_blocks_install(self):
        with patch("manage.shutil.which", return_value="/fake/bin"):
            self.fake_system(False).preflight("http://127.0.0.1:3000", no_probe=True)

    def test_nginx_with_sub_module_remains_compatible(self):
        from unittest.mock import patch
        with patch("manage.shutil.which", return_value="/fake/bin"):
            self.fake_system(True).preflight("http://127.0.0.1:3000", no_probe=True)

    def test_proxy_does_not_claim_nas_root_api(self):
        block = render("12345", "http://127.0.0.1:3000")
        self.assertNotIn("location /api", block)
        self.assertNotIn("sub_filter", block)
        self.assertIn("proxy_pass http://127.0.0.1:3000", block)
        self.assertFalse((ROOT / "src/ui/web").exists())
        self.assertFalse((ROOT / "frontend").exists())


class StaticCGI(unittest.TestCase):
    def test_entry_streaming_and_mime(self):
        out = io.BytesIO()
        serve(ROOT / "src/ui", ROOT / "src/ui/index.html", out)
        headers, body = out.getvalue().split(b"\r\n\r\n", 1)
        self.assertIn(b"Content-Type: text/html", headers)
        self.assertEqual(body, (ROOT / "src/ui/index.html").read_bytes())

    def test_external_path_cgi_and_directories_rejected(self):
        for requested in (ROOT / "INFO", ROOT / "src/ui", ROOT / "deploy/static_cgi.py", ROOT / "src/ui/../secret"):
            out = io.BytesIO()
            serve(ROOT / "src/ui", requested, out)
            self.assertTrue(out.getvalue().startswith(b"Status: 404"))

    def test_wasm_mime_supported(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "decoder.wasm"
            path.write_bytes(b"\x00asm")
            out = io.BytesIO()
            serve(temp, path, out)
            self.assertIn(b"application/wasm", out.getvalue())


class LiveDockerWeb(unittest.TestCase):
    """Exercise live HTTP content and the actual installed CGI entry process."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "src/ui"
        self.root.mkdir(parents=True)
        self.responses = {
            "/index.html": (200, "text/html", b'<html><head></head><body><div id="app"></div></body></html>'),
            "/assets/app.js": (200, "application/javascript", b'const base="/api";const other="/api/unchanged";'),
        }
        self.requests = []
        fixture = self
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                fixture.requests.append((self.path, self.headers))
                status, mime, body = fixture.responses.get(self.path, (404, "text/plain", b"missing"))
                self.send_response(status)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(len(body)))
                if getattr(fixture, "compressed", False):
                    self.send_header("Content-Encoding", "gzip")
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, *args):
                pass
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.config = {"uid": "12345", "port": self.server.server_port}

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def request(self, path, **env):
        out = io.BytesIO()
        with patch.dict(os.environ, {"REQUEST_METHOD": "GET", **env}):
            serve(self.root, self.root / path, out, proxy=self.config)
        return out.getvalue().split(b"\r\n\r\n", 1)

    def test_entry_uses_live_docker_html_without_copy(self):
        headers, body = self.request("web/index.html")
        self.assertIn(b"Content-Type: text/html", headers)
        self.assertIn(b'/plugin/12345/bililivewatch/bridge.js?v=0.2.1', body)
        self.assertIn(b"Cache-Control: no-store", headers)
        self.responses["/index.html"] = (200, "text/html", self.responses["/index.html"][2] + b"<!-- docker updated -->")
        self.assertIn(b"docker updated", self.request("web/index.html")[1])
        self.assertFalse((self.root / "web").exists())

    def test_api_literal_rewrite_and_live_javascript_update(self):
        headers, body = self.request("web/assets/app.js", HTTP_COOKIE="nas-secret", HTTP_AUTHORIZATION="docker-secret")
        self.assertIn(b"application/javascript", headers)
        self.assertEqual(body, b'const base="/plugin/12345/bililivewatch/api";const other="/api/unchanged";')
        self.assertIsNone(self.requests[-1][1].get("Cookie"))
        self.assertIsNone(self.requests[-1][1].get("Authorization"))
        self.assertEqual(self.requests[-1][1]["Accept-Encoding"], "identity")

    def test_head_has_rewritten_length_and_no_body(self):
        _, body = self.request("web/assets/app.js")
        headers, empty = self.request("web/assets/app.js", REQUEST_METHOD="HEAD")
        self.assertIn(f"Content-Length: {len(body)}".encode(), headers)
        self.assertEqual(empty, b"")

    def test_nas_cgi_process_reads_private_installed_config(self):
        cgi = self.root / "bililivewatch.cgi"
        shutil.copyfile(ROOT / "deploy/static_cgi.py", cgi)
        (self.root.parent / "proxy.json").write_text(json.dumps(self.config))
        result = subprocess.run([sys.executable, str(cgi)], env={**os.environ, "REQUEST_METHOD": "GET", "FILE_REQ": str(self.root / "web/assets/app.js")}, capture_output=True, check=True)
        self.assertIn(b'const base="/plugin/12345/bililivewatch/api";', result.stdout)
        self.assertEqual(result.stderr, b"")
        self.assertTrue(self.request("../proxy.json")[0].startswith(b"Status: 404"))

    def test_non_web_or_non_read_requests_never_reach_docker(self):
        for path in ("web/../secret.txt", "web/secrets.json", "web/http://example.com/a.js", "web/../../../secret.js"):
            self.assertTrue(self.request(path)[0].startswith(b"Status: 404"), path)
        self.assertTrue(self.request("web/assets/app.js", REQUEST_METHOD="POST")[0].startswith(b"Status: 405"))
        self.assertEqual(self.requests, [])

    def test_upstream_redirect_and_errors_are_not_followed(self):
        for status in (302, 401, 500):
            self.responses["/assets/app.js"] = (status, "text/plain", b"private upstream message")
            headers, body = self.request("web/assets/app.js")
            self.assertTrue(headers.startswith(b"Status: 502"))
            self.assertNotIn(b"private", body)
        self.assertTrue(self.request("web/assets/missing.js")[0].startswith(b"Status: 404"))

    def test_wrong_mime_compression_and_oversized_responses_fail_cleanly(self):
        self.responses["/assets/app.js"] = (200, "text/html", b"<html>fallback</html>")
        self.assertTrue(self.request("web/assets/app.js")[0].startswith(b"Status: 502"))
        self.responses["/assets/app.js"] = (200, "application/javascript", b"x" * 64)
        with patch("static_cgi.MAX_WEB_BYTES", 16):
            self.assertTrue(self.request("web/assets/app.js")[0].startswith(b"Status: 502"))
        self.compressed = True
        self.assertTrue(self.request("web/assets/app.js")[0].startswith(b"Status: 502"))


if __name__ == "__main__":
    unittest.main()
