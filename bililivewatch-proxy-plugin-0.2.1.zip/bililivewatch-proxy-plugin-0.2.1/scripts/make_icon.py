#!/usr/bin/env python3
"""Dependency-free 300px PNG plugin icon; generated from simple geometry."""
from pathlib import Path
import struct
import zlib


def make():
    rows = bytearray()
    for y in range(300):
        rows.append(0)
        for x in range(300):
            edge = max(42 - x, x - 257, 42 - y, y - 257, 0)
            corner = ((x - (42 if x < 150 else 257)) ** 2 + (y - (42 if y < 150 else 257)) ** 2) ** .5
            outside = (x < 42 or x > 257) and (y < 42 or y > 257) and corner > 42
            color = (0, 0, 0, 0) if outside else (255, int(112 + 30 * y / 300), 35, 255)
            if 54 <= x <= 246 and 73 <= y <= 237:
                color = (255, 255, 255, 255)
            if 54 <= x <= 246 and 102 <= y <= 110:
                color = (255, 154, 75, 255)
            if (86 <= x <= 100 or 200 <= x <= 214) and 53 <= y <= 87:
                color = (255, 255, 255, 255)
            if 126 <= x <= 192 and abs(y - 171) <= (192 - x) * .64:
                color = (245, 112, 32, 255)
            rows.extend(color)
    def chunk(name, content):
        return struct.pack(">I", len(content)) + name + content + struct.pack(">I", zlib.crc32(name + content))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 300, 300, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b"")


if __name__ == "__main__":
    target = Path(__file__).resolve().parents[1] / "src/ui/icon.png"
    target.write_bytes(make())
    print(target)
