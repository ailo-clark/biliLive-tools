#!/usr/bin/env python3
"""Package local files, source and manual; no Git or deployment operations."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAME = "bililivewatch-proxy-plugin-0.2.1"
EXCLUDE = {".git", ".build", "node_modules", "__pycache__", "dist"}


def package(output):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    info = json.loads((ROOT / "INFO").read_text())
    info["size"] = sum(p.stat().st_size for folder in ("src", "scripts") for p in (ROOT / folder).rglob("*")
                       if p.is_file() and "__pycache__" not in p.parts)
    (ROOT / "INFO").write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n")
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and not p.is_symlink()
                   and not EXCLUDE.intersection(p.relative_to(ROOT).parts)
                   and p.suffix not in (".pyc", ".zip") and output not in p.parents
                   and p.name != "MANIFEST.json")
    required = ["src/ui/bridge.js", "src/ui/icon.png", "BUILD.json", "部署手册.md", "测试报告.md", "LICENSE"]
    if any((ROOT / name).exists() for name in ("frontend", "vendor", "src/ui/web")):
        raise RuntimeError("代理版不能包含单独前端或 Docker 网页副本")
    if not all((ROOT / name) in files for name in required):
        raise RuntimeError("缺少构建产物、手册、源码或测试报告，请先完成构建和测试")
    manifest = {"format": 1, "plugin": "bililivewatch", "version": "0.2.1",
                "files": {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    files.append(manifest_path)
    archives = [output / (NAME + ".zip"), output / (NAME + ".tar.gz")]
    with zipfile.ZipFile(archives[0], "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in files:
            dest = NAME + "/" + source.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(dest, (2026, 10, 16, 0, 0, 0))
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if source.suffix == ".sh" or source.name == "control" else 0o644
            info.external_attr = (0o100000 | mode) << 16
            archive.writestr(info, source.read_bytes(), compresslevel=9)
    with tarfile.open(archives[1], "w:gz") as archive:
        for source in files:
            info = archive.gettarinfo(str(source), arcname=NAME + "/" + source.relative_to(ROOT).as_posix())
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            info.mode = 0o755 if source.suffix == ".sh" or source.name == "control" else 0o644
            info.mtime = 1792108800
            with source.open("rb") as stream:
                archive.addfile(info, stream)
    checksums = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.name + "\n" for p in archives)
    (output / "bililivewatch-proxy-0.2.1-SHA256SUMS.txt").write_text(checksums)
    print(checksums, end="")
    return archives


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(ROOT / "dist"))
    package(parser.parse_args().output)
