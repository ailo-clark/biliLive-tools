// Optional local HTML manual generation using the existing upstream dependency.
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const repo = path.resolve(process.argv[2] || "../biliLive-tools");
const require = createRequire(path.join(repo, "packages/app/package.json"));
const { marked } = await import(pathToFileURL(require.resolve("marked")));
const body = marked.parse(fs.readFileSync(path.join(root, "部署手册.md"), "utf8"));
const html = `<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>录播观看插件：部署与回滚手册</title><style>
:root{color-scheme:light dark}body{margin:0;font:16px/1.8 system-ui,-apple-system,"Microsoft YaHei",sans-serif;background:#f5f7fa;color:#182230}article{max-width:960px;margin:32px auto;padding:32px 36px;background:white;border-radius:16px;box-shadow:0 4px 30px #1020300a}h1{font-size:28px;line-height:1.5}h2{font-size:22px;margin-top:36px;border-bottom:1px solid #e2e8f0;padding-bottom:8px}a{color:#096d52}pre{overflow:auto;background:#111827;color:#e5edf5;padding:18px;border-radius:10px;font-size:14px;line-height:1.6}code{font-family:ui-monospace,Consolas,monospace;overflow-wrap:anywhere}p>code,li>code,td>code{background:#edf2f7;border-radius:4px;padding:2px 5px}table{border-collapse:collapse;display:block;overflow-x:auto;margin:20px 0}th,td{border:1px solid #d7e0e9;padding:10px 12px;text-align:left}th{background:#f1f5f9}@media(max-width:640px){article{margin:0;border-radius:0;padding:16px}h1{font-size:24px}pre{padding:12px}body{font-size:15px}}@media(prefers-color-scheme:dark){body{background:#11151b;color:#e2e8f0}article{background:#1b212b}h2{border-color:#3b4554}th,td{border-color:#435066}th,p>code,li>code,td>code{background:#293344}a{color:#73dfbb}}@media print{article{margin:0;padding:0;box-shadow:none}pre{white-space:pre-wrap}table{display:table}h2{break-after:avoid}}
</style></head><body><article>${body}</article></body></html>`;
fs.writeFileSync(path.join(root, "部署手册.html"), html);
console.log("Generated standalone HTML manual");
