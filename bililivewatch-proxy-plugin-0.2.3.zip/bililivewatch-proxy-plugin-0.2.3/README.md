# 小米 NAS 录播入口 · Docker 网页代理版 0.2.3

统一使用已有 fullstack Docker 在 3000 端口提供的网页。插件没有独立的观看首页、日历、播放器或前端构建产物；Docker 更新网页后，重新打开插件即可使用新网页。

```text
NAS App 的插件入口壳
  → iframe 打开 /plugin/<UID>/bililivewatch/web/index.html#/mobile
  → NAS 已有 plugin.cgi 调用插件 Python 入口，实时读取 Docker HTML/JS
  → API、视频、CSS 等由 NAS Nginx 直接转发到 127.0.0.1:3000
  → 页面脚本、CSS、接口、视频均实时来自现有 Docker
```

插件壳承载原网页，避免 NAS 宿主样式干扰。代理给原 HTML 注入存储隔离和手机全屏适配脚本，并把返回 JavaScript 中的默认 API 地址 `/api` 替换成插件前缀；不修改容器里的文件或业务逻辑。

- [部署与回滚手册](部署手册.md) / [离线 HTML 手册](部署手册.html)
- [设计与测试说明](开发说明.md) / [测试报告](测试报告.md)
- 检查：`sh deploy/check.sh --uid 你的数字UID`
- 部署：`sh deploy/deploy.sh --uid 你的数字UID`
- 回滚：`sh /data/bililive-nas-plugin/runtime/rollback.sh`

默认 upstream 为 `http://127.0.0.1:3000`，可通过 `--upstream http://127.0.0.1:实际端口` 设置。

0.2.3 修复了手机全屏仍保持竖屏的问题。横向视频点击原播放器的全屏按钮后优先请求系统横屏；App 拒绝方向锁定时自动旋转播放器及控制栏，原生全屏不可用时使用页面全屏。进度条点击和拖动按旋转后的坐标处理，退出时恢复布局、释放本次方向锁定。竖向视频保持竖向，电脑沿用原行为；系统状态栏及整个 NAS App 能否旋转仍由 App 控制。

已经成功安装 0.2.2 的用户按手册先回滚插件，再部署本版并彻底退出、重开 App。无需更换 Docker 镜像或 Compose；录像、数据库和观看进度保留。

0.2.1 修复了 NAS Nginx 缺少 `http_sub_module` 时无法部署的问题。HTML/JS 的适配改由插件已有的 Python CGI 入口完成，不需要这个模块、不替换系统 Nginx、不新增常驻 HTTP 服务。视频与 API 仍由 Nginx 直接转发，不经过 Python。

0.2.2 修复了共享配置重复写入误报。NAS 上 `/etc/config/plugin` 与 `/data/etc/upper/config/plugin` 可能是同一份配置的两个入口；安装器会通过路径与 Linux overlay 挂载信息识别，只通过前者写一次，并在回滚和重启恢复时沿用同一处理方式。两份真正独立的文件仍分别管理，真实外部修改仍会阻止覆盖。

如果 0.2.1 曾提示“共享配置在部署过程中发生变化”，先运行 `sh /data/bililive-nas-plugin/runtime/status.sh`。状态为 `rolled_back` 表示自动回滚已完成，直接解压本版检查和部署；其他状态先按手册回滚，不要删除状态或备份来强行重装。

如果 0.2.0 仅报模块缺失且提示未修改配置，直接解压本版检查和部署，无需回滚。已成功安装 0.1.0/0.2.0 的用户先使用原回滚脚本卸载，再部署本版。录像、Docker 配置和观看进度都会保留。

按用户授权仅向 GitHub 独立下载分支上传压缩包和文档，不提交解压后的插件源码。真实小米 NAS、官方 App 和移动网络视频通道仍须按手册验收。
