const assert = require("node:assert/strict");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

// Real Chromium, original Docker player and actual media. Only unsupported
// platform APIs are fault-injected; no video or playback events are simulated.
module.exports = async function fullscreenChecks(
  browser,
  origin,
  prefix,
  key,
  root,
) {
  execFileSync("ffmpeg", [
    "-v",
    "error",
    "-y",
    "-f",
    "lavfi",
    "-i",
    "testsrc2=size=200x400:rate=10",
    "-t",
    "2",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    path.join(root, "docker-web/assets/portrait-fullscreen-fixture.mp4"),
  ]);
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    userAgent:
      "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
  });
  try {
    await context.addCookies([
      { name: "nas_test", value: "local-auth", url: origin },
    ]);
    await context.addInitScript(
      ({ key }) => {
        localStorage.setItem("bililivewatch:12345:key", key);
        localStorage.setItem("bililivewatch:12345:api", "/api");
        localStorage.setItem(
          "bililivewatch:12345:changelog",
          JSON.stringify({ "3.22.2": true }),
        );
        window.__locks = [];
        window.__unlocks = 0;
        Object.defineProperty(screen.orientation, "lock", {
          configurable: true,
          writable: true,
          value: (value) => {
            window.__locks.push(value);
            return Promise.reject(
              new DOMException(
                "Simulated Android WebView lock restriction",
                "NotSupportedError",
              ),
            );
          },
        });
        Object.defineProperty(screen.orientation, "unlock", {
          configurable: true,
          value: () => {
            window.__unlocks++;
          },
        });
      },
      { key },
    );
    const page = await context.newPage();
    page.setDefaultTimeout(12000);
    const errors = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto(origin + prefix + "/index.html#/");
    const frame = page.frameLocator("iframe");
    await frame.getByRole("link", { name: "文件", exact: true }).click();
    await frame.getByText("clip.mp4", { exact: true }).waitFor();
    await frame.getByRole("button", { name: /^(播放|继续观看)$/ }).click();
    const inner = page
      .frames()
      .find((item) => item.url().includes("/web/index.html"));
    await inner.waitForFunction(
      () => document.querySelector("video")?.readyState >= 1,
    );
    await inner.evaluate(() => {
      window.__originalVideo = document.querySelector("video");
      window.__originalVideo.pause();
      window.__originalVideoSource = window.__originalVideo.currentSrc;
      window.__nativeFullscreen = Element.prototype.requestFullscreen;
      window.__webkitFullscreen = Element.prototype.webkitRequestFullscreen;
      window.__nativeResizeObserver = window.ResizeObserver;
    });
    // A containing block in the NAS host must not trap page fullscreen.
    const hostTransform = await page.evaluate(() => {
      document.body.style.transform = "translateZ(0)";
      return document.body.style.transform;
    });
    const originalFrame = await page.locator("iframe").boundingBox();
    async function enter(native, rotated = true) {
      await frame.locator(".art-control-fullscreen").click();
      await frame
        .locator(
          '.bililivewatch-fullscreen-stage[data-rotated="' + rotated + '"]',
        )
        .waitFor();
      if (native)
        await inner.waitForFunction(() => !!document.fullscreenElement);
      assert(
        await inner.evaluate(
          () => document.querySelector("video") === window.__originalVideo,
        ),
      );
      const sizes = await inner.evaluate(() => {
        const player = document.querySelector(".art-video-player");
        const stage = document.querySelector(".bililivewatch-fullscreen-stage");
        return {
          width: player.clientWidth,
          height: player.clientHeight,
          stageWidth: stage.clientWidth,
          stageHeight: stage.clientHeight,
        };
      });
      assert(
        rotated ? sizes.width > sizes.height : sizes.width < sizes.height,
        JSON.stringify(sizes),
      );
      assert(
        Math.abs(
          sizes.width - (rotated ? sizes.stageHeight : sizes.stageWidth),
        ) <= 1,
      );
      assert(
        Math.abs(
          sizes.height - (rotated ? sizes.stageWidth : sizes.stageHeight),
        ) <= 1,
      );
    }
    async function exited() {
      await frame
        .locator(".bililivewatch-fullscreen-stage")
        .waitFor({ state: "detached" });
      await inner.waitForFunction(() => !document.fullscreenElement);
      assert(
        await inner.evaluate(
          () => document.querySelector("video") === window.__originalVideo,
        ),
      );
      assert.equal(
        await page.evaluate(() => document.body.style.transform),
        hostTransform,
      );
      assert.equal(
        await page
          .locator("iframe")
          .evaluate((element) => element.style.position),
        "",
      );
      const box = await page.locator("iframe").boundingBox();
      assert(Math.abs(box.height - originalFrame.height) <= 2);
    }
    await enter(true);
    await inner.waitForFunction(() => window.__locks.includes("landscape"));
    // Seek and drag in physical screen coordinates after the 90-degree transform.
    let bar = await frame.locator(".art-control-progress").boundingBox();
    await page.touchscreen.tap(bar.x + bar.width / 2, bar.y + bar.height * 0.5);
    await inner.waitForFunction(
      () => Math.abs(document.querySelector("video").currentTime - 6) < 0.35,
    );
    const cdp = await context.newCDPSession(page);
    bar = await frame.locator(".art-control-progress").boundingBox();
    const point = (ratio) => [
      { x: bar.x + bar.width / 2, y: bar.y + bar.height * ratio },
    ];
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchStart",
      touchPoints: point(0.2),
    });
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: point(0.7),
    });
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchEnd",
      touchPoints: [],
    });
    await inner.waitForFunction(() => {
      const video = document.querySelector("video");
      return (
        !video.seeking &&
        video.readyState >= 2 &&
        Math.abs(video.currentTime - 8.4) < 0.35
      );
    });
    await page.screenshot({
      path: path.join(root, "android-landscape-fullscreen.png"),
    });
    await frame.getByRole("button", { name: "退出全屏", exact: true }).click();
    await exited();

    // No native fullscreen permission: the same controls work in page fullscreen.
    await inner.evaluate(() => {
      Element.prototype.requestFullscreen = () =>
        Promise.reject(
          new DOMException(
            "Simulated fullscreen restriction",
            "NotAllowedError",
          ),
        );
    });
    await enter(false);
    assert.equal(
      await inner.evaluate(() => !!document.fullscreenElement),
      false,
    );
    await page.screenshot({
      path: path.join(root, "android-landscape-page-fullscreen.png"),
    });
    await page.keyboard.press("Escape");
    await exited();

    // WebViews may omit the native API completely.
    await inner.evaluate(() => {
      Element.prototype.requestFullscreen = undefined;
      Element.prototype.webkitRequestFullscreen = undefined;
      window.ResizeObserver = undefined;
    });
    await enter(false);
    await frame.locator(".art-control-fullscreen").click();
    await exited();

    // Resolved lock and orientation changes: stop rotating when the viewport is landscape.
    await inner.evaluate(() => {
      Element.prototype.requestFullscreen = window.__nativeFullscreen;
      Element.prototype.webkitRequestFullscreen = window.__webkitFullscreen;
      window.ResizeObserver = window.__nativeResizeObserver;
      screen.orientation.lock = (value) => {
        window.__locks.push(value);
        return Promise.resolve();
      };
    });
    await enter(true);
    const unlocks = await inner.evaluate(() => window.__unlocks);
    await page.setViewportSize({ width: 844, height: 390 });
    await frame
      .locator('.bililivewatch-fullscreen-stage[data-rotated="false"]')
      .waitFor();
    await frame.getByRole("button", { name: "退出全屏", exact: true }).click();
    await inner.waitForFunction(
      (before) => window.__unlocks === before + 1,
      unlocks,
    );
    await page.setViewportSize({ width: 390, height: 844 });
    await exited();

    // A late lock resolution after exit must release its lock and never reopen UI.
    await inner.evaluate(() => {
      screen.orientation.lock = () =>
        new Promise((resolve) => {
          window.__resolveLock = resolve;
        });
    });
    await enter(true);
    await inner.waitForFunction(() => !!window.__resolveLock);
    await frame.getByRole("button", { name: "退出全屏", exact: true }).click();
    const before = await inner.evaluate(() => window.__unlocks);
    await inner.evaluate(() => window.__resolveLock());
    await inner.waitForFunction(
      (value) => window.__unlocks === value + 1,
      before,
    );
    await exited();

    // Closing the NAS plugin must also restore the host while fullscreen is active.
    await inner.evaluate(() => {
      Element.prototype.requestFullscreen = undefined;
      Element.prototype.webkitRequestFullscreen = undefined;
    });
    // Portrait recordings retain portrait fullscreen instead of being forced sideways.
    await inner.evaluate((source) => {
      const video = document.querySelector("video");
      video.src = source;
      video.load();
    }, prefix + "/web/assets/portrait-fullscreen-fixture.mp4");
    await inner.waitForFunction(() => {
      const video = document.querySelector("video");
      return video.videoHeight > video.videoWidth && video.readyState >= 1;
    });
    await enter(false, false);
    await frame.getByRole("button", { name: "退出全屏", exact: true }).click();
    await exited();
    await inner.evaluate(() => {
      const video = document.querySelector("video");
      video.src = window.__originalVideoSource;
      video.load();
    });
    await inner.waitForFunction(() => {
      const video = document.querySelector("video");
      return video.videoWidth > video.videoHeight && video.readyState >= 1;
    });
    // The actual session player must auto-advance at media EOF in page fullscreen too.
    await inner.evaluate(() => {
      location.hash = "#/mobile";
    });
    await frame
      .getByRole("button", {
        name: "查看 插件测试主播 的录播日历",
        exact: true,
      })
      .click();
    await frame.getByRole("button", { name: /2026-10-15，1 场录像/ }).click();
    await frame.locator(".day-sessions .session-entry").click();
    // Prior file-playback checks may have advanced the shared watch state.
    // Explicitly choose episode 2 through the actual UI before testing 2 -> 3.
    await frame
      .getByRole("button", { name: "播放第 2 段", exact: true })
      .click();
    await inner.waitForFunction(
      () =>
        Number(
          document.querySelector(".episode.selected .episode-number")
            ?.textContent,
        ) === 2 &&
        document.querySelector("video")?.readyState >= 2 &&
        Array.from(document.querySelectorAll(".playback-controls button")).find(
          (button) => button.textContent.trim() === "下一段",
        )?.disabled === false,
    );
    const episode = await frame
      .locator(".episode.selected .episode-number")
      .textContent();
    assert.equal(Number(episode), 2);
    await inner.evaluate(() => {
      window.__originalVideo = document.querySelector("video");
    });
    await enter(false);
    await inner.evaluate(() => {
      const video = document.querySelector("video");
      video.currentTime = video.duration - 0.2;
      return video.play();
    });
    await inner.waitForFunction(
      (expected) => {
        const video = document.querySelector("video");
        return (
          Number(
            document.querySelector(".episode.selected .episode-number")
              ?.textContent,
          ) === expected &&
          video === window.__originalVideo &&
          !video.paused &&
          video.currentTime > 0
        );
      },
      Number(episode) + 1,
    );
    assert.equal(
      await frame
        .locator('.bililivewatch-fullscreen-stage[data-rotated="true"]')
        .count(),
      1,
    );
    assert.equal(
      await inner.evaluate(() => !!document.fullscreenElement),
      false,
    );
    await inner.evaluate(() => document.querySelector("video").pause());
    await page.evaluate(() => window.dispatchEvent(new Event("unmount")));
    assert.equal(await page.locator("iframe").count(), 0);
    assert.equal(
      await page.evaluate(() => document.body.style.transform),
      hostTransform,
    );
    assert.equal(errors.length, 0, errors.join("\n"));
    console.log(
      "PASS Android fullscreen: native lock rejection, rotated tap/drag seek, native API rejection/absence, resize, unlock/late-lock cleanup, portrait video, real-ended page-fullscreen autoplay, same video, host restoration, plugin close",
    );
  } finally {
    await context.close();
  }
};
