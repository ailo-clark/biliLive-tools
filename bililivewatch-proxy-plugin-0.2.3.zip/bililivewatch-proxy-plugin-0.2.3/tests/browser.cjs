// Requires the existing monorepo's compiled CLI/shared packages, ffmpeg,
// Chromium, Playwright and nginx. All data/services below are disposable fixtures.
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawn, execFileSync } = require("node:child_process");
const { randomBytes, createHash } = require("node:crypto");
const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const pkg = path.resolve(__dirname, "..");
const repo = process.env.BILILIVE_REPO || "/workspace/biliLive-tools";
const nginx =
  process.env.NGINX_BIN ||
  "/workspace/cloud-setup/tools/nginx-proxy/sbin/nginx";
const { chromium } = require(
  process.env.PLAYWRIGHT_MODULE ||
    "/workspace/cloud-setup/browser/node_modules/playwright",
);
const Database = require(
  path.join(repo, "packages/shared/node_modules/better-sqlite3"),
);
const root =
  process.env.PLUGIN_TEST_OUTPUT ||
  fs.mkdtempSync(path.join(os.tmpdir(), "bililive-plugin-e2e-"));
fs.mkdirSync(root, { recursive: true });
fs.rmSync(path.join(root, "result.json"), { force: true });
fs.rmSync(path.join(root, "data"), { recursive: true, force: true });
fs.mkdirSync(path.join(root, "data"));
fs.mkdirSync(path.join(root, "videos"), { recursive: true });
const secret = randomBytes(32).toString("hex");
const prefix = "/plugin/12345/bililivewatch";
const origin = "http://127.0.0.1:18043";
const headers = {
  Authorization: secret,
  Cookie: "nas_test=local-auth",
  "Content-Type": "application/json",
};
let backend, browser;
const children = [];
function child(cmd, args, options = {}) {
  const fd = fs.openSync(path.join(root, "services.log"), "a");
  const proc = spawn(cmd, args, { stdio: ["ignore", fd, fd], ...options });
  fs.closeSync(fd);
  children.push(proc);
  return proc;
}
function launch() {
  backend = child(
    process.execPath,
    [
      path.join(repo, "packages/CLI/lib/index.cjs"),
      "server",
      "-c",
      path.join(root, "config.json"),
    ],
    {
      cwd: path.join(repo, "packages/CLI"),
      env: {
        ...process.env,
        TZ: "Asia/Shanghai",
        BILILIVE_TOOLS_PASSKEY: secret,
      },
    },
  );
}
async function stop(proc) {
  if (!proc || proc.exitCode !== null || proc.signalCode !== null) return;
  await new Promise((resolve) => {
    proc.once("exit", resolve);
    proc.kill("SIGTERM");
  });
}
async function ready(url, init) {
  for (let i = 0; i < 100; i++) {
    try {
      if ((await fetch(url, init)).ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error("Service did not become ready: " + url);
}
const api = (url, method = "GET", data) =>
  fetch(origin + prefix + "/api" + url, {
    method,
    headers,
    body: data === undefined ? undefined : JSON.stringify(data),
  });
async function main() {
  const config = {
    port: 18041,
    host: "127.0.0.1",
    configFolder: path.join(root, "data"),
    ffmpegPath: "/usr/bin/ffmpeg",
    ffprobePath: "/usr/bin/ffprobe",
    mesioPath: "mesio",
    bililiveRecorderPath: "BililiveRecorder.Cli",
    audiowaveformPath: "audiowaveform",
    danmakuFactoryPath: "DanmakuFactory",
    logPath: path.join(root, "main.log"),
  };
  fs.writeFileSync(path.join(root, "config.json"), JSON.stringify(config));
  launch();
  await ready("http://127.0.0.1:18041/common/version", {
    headers: { Authorization: secret },
  });
  await stop(backend);
  const appConfigPath = path.join(root, "data/appConfig.json");
  const appConfig = JSON.parse(fs.readFileSync(appConfigPath));
  appConfig.recorder.savePath = path.join(root, "videos");
  appConfig.recorders = [];
  fs.writeFileSync(appConfigPath, JSON.stringify(appConfig));
  execFileSync("ffmpeg", [
    "-v",
    "error",
    "-y",
    "-f",
    "lavfi",
    "-i",
    "testsrc=size=480x270:rate=10",
    "-f",
    "lavfi",
    "-i",
    "anullsrc=r=44100:cl=stereo",
    "-t",
    "12",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-preset",
    "ultrafast",
    "-c:a",
    "aac",
    "-movflags",
    "+faststart",
    path.join(root, "videos/clip.mp4"),
  ]);
  const db = new Database(path.join(root, "data/app.db"));
  db.prepare(
    "INSERT INTO streamer (id,name,room_id,platform) VALUES (9001,?,?,?)",
  ).run("插件测试主播", "9001", "Bilibili");
  const start = Date.parse("2026-10-15T12:00:00Z");
  const insert = db.prepare(
    "INSERT INTO record_history (id,streamer_id,live_id,live_start_time,record_start_time,record_end_time,title,video_file,video_duration) VALUES (?,9001,?,?,?,?,?,?,12)",
  );
  for (let i = 0; i < 3; i++)
    insert.run(
      9001 + i,
      "plugin-live",
      start,
      start + i * 12000,
      start + (i + 1) * 12000,
      "插件测试场次",
      path.join(root, "videos/clip.mp4"),
    );
  const records = db.prepare("SELECT * FROM record_history").all();
  const schema = db
    .prepare("SELECT sql FROM sqlite_master ORDER BY name")
    .all();
  db.close();
  const { WatchHistoryStore, recordWatchKey } = await import(
    pathToFileURL(path.join(repo, "packages/shared/lib/db/watchHistory.js"))
  );
  const store = new WatchHistoryStore(path.join(root, "data"));
  store.initializeExistingRecords(records);
  for (const record of records) {
    const state = store.ensure({
      key: recordWatchKey(record),
      filePath: record.video_file,
      title: record.title,
      recordId: record.id,
    });
    assert(
      store.update(state.key, { revision: state.revision, action: "unwatched" })
        .state,
    );
  }
  const first = store.get(recordWatchKey(records[0]));
  assert.equal(
    store.update(first.key, {
      revision: first.revision,
      action: "progress",
      position: 7,
      duration: 12,
    }).state.position,
    7,
  );
  store.close();
  launch();
  await ready("http://127.0.0.1:18041/common/version", {
    headers: { Authorization: secret },
  });
  const dockerWeb = path.join(root, "docker-web");
  fs.rmSync(dockerWeb, { recursive: true, force: true });
  fs.cpSync(path.join(repo, "packages/app/out/renderer"), dockerWeb, {
    recursive: true,
  });
  execFileSync("python3", [
    path.join(__dirname, "render_test_nginx.py"),
    root,
    dockerWeb,
  ]);
  child("python3", [path.join(__dirname, "static_server.py"), "18044"]);
  execFileSync(nginx, [
    "-p",
    root + "/",
    "-c",
    path.join(root, "nginx.conf"),
    "-t",
  ]);
  child(nginx, [
    "-p",
    root + "/",
    "-c",
    path.join(root, "nginx.conf"),
    "-g",
    "daemon off;",
  ]);
  await ready(origin + prefix + "/api/common/version", { headers });
  assert.equal(
    (
      await fetch(origin + prefix + "/api/common/version", {
        headers: { Authorization: secret },
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await fetch(origin + prefix + "/api/common/version", {
        headers: { Cookie: "nas_test=local-auth" },
      })
    ).status,
    401,
  );
  assert.equal((await api("/config")).status, 200);
  assert.equal(
    (await fetch(origin + "/api/common/version", { headers })).status,
    418,
  );
  const upstreamHTML = await (
    await fetch("http://127.0.0.1:18042/index.html")
  ).text();
  const proxiedHTML = await (
    await fetch(origin + prefix + "/web/index.html", { headers })
  ).text();
  const injected =
    '<script src="' +
    prefix +
    '/bridge.js?v=0.2.3"></script><script src="' +
    prefix +
    '/fullscreen.js?v=0.2.3"></script>';
  assert.equal(
    proxiedHTML,
    upstreamHTML.replace("<head>", "<head>" + injected),
  );
  const entry = upstreamHTML.match(/src="([^"]+\.js)"/)[1].replace(/^\.\//, "");
  const entryOriginal = await (
    await fetch("http://127.0.0.1:18042/" + entry)
  ).text();
  const entryProxy = await (
    await fetch(origin + prefix + "/web/" + entry, { headers })
  ).text();
  const rewriteAPI = (text) =>
    text
      .replaceAll('"/api"', '"' + prefix + '/api"')
      .replaceAll("'/api'", "'" + prefix + "/api'")
      .replaceAll("`/api`", "`" + prefix + "/api`");
  assert.equal(entryProxy, rewriteAPI(entryOriginal));
  const css = upstreamHTML
    .match(/href="([^\"]+\.css)"/)[1]
    .replace(/^\.\//, "");
  assert.deepEqual(
    Buffer.from(
      await (
        await fetch(origin + prefix + "/web/" + css, { headers })
      ).arrayBuffer(),
    ),
    fs.readFileSync(path.join(dockerWeb, css)),
  );
  const updated =
    upstreamHTML + "\n<!-- docker-updated-without-plugin-reinstall -->";
  fs.writeFileSync(path.join(dockerWeb, "index.html"), updated);
  assert(
    (
      await (
        await fetch(origin + prefix + "/web/index.html", { headers })
      ).text()
    ).includes("docker-updated-without-plugin-reinstall"),
  );
  fs.writeFileSync(path.join(dockerWeb, "index.html"), upstreamHTML);
  assert.equal((await fetch(origin + prefix + "/web/index.html")).status, 403);
  assert.equal((await fetch(origin + prefix + "/web/" + entry)).status, 403);
  assert(!fs.existsSync(path.join(pkg, "src/ui/web")));
  const file = await (await api("/record-history/file/9001")).json();
  const videoURL = origin + prefix + "/api/common/video/" + file.videoFileId;
  const bytes = fs.readFileSync(path.join(root, "videos/clip.mp4"));
  const partial = await fetch(videoURL, {
    headers: { ...headers, Range: "bytes=20-99" },
  });
  assert.equal(partial.status, 206);
  assert.equal(
    partial.headers.get("content-range"),
    `bytes 20-99/${bytes.length}`,
  );
  assert.deepEqual(
    Buffer.from(await partial.arrayBuffer()),
    bytes.subarray(20, 100),
  );
  const full = await fetch(videoURL, { headers });
  assert.equal(full.status, 200);
  assert.equal(full.headers.get("content-length"), String(bytes.length));
  assert.deepEqual(Buffer.from(await full.arrayBuffer()), bytes);
  const suffix = await fetch(videoURL, {
    headers: { ...headers, Range: "bytes=-10" },
  });
  assert.equal(suffix.status, 206);
  assert.deepEqual(
    Buffer.from(await suffix.arrayBuffer()),
    bytes.subarray(-10),
  );
  assert.equal(
    (
      await fetch(videoURL, {
        headers: { ...headers, Range: `bytes=${bytes.length}-` },
      })
    ).status,
    416,
  );
  const head = await fetch(videoURL, { method: "HEAD", headers });
  assert.equal(head.status, 200);
  assert.equal(head.headers.get("content-length"), String(bytes.length));
  assert.equal((await fetch(videoURL)).status, 403);
  console.log(
    "PASS real nginx: Docker HTML/JS live proxy, exact API-prefix-only rewrite, NAS auth, 200/206/416/HEAD",
  );
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_BIN || "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
  });
  await ctx.addCookies([
    { name: "nas_test", value: "local-auth", url: origin },
  ]);
  await ctx.addInitScript(() => {
    if (!localStorage.getItem("key"))
      localStorage.setItem("key", "NAS-HOST-SENTINEL");
  });
  const page = await ctx.newPage();
  page.setDefaultTimeout(15000);
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  const requests = [];
  page.on("request", (r) => requests.push(r.url()));
  await page.goto(origin + prefix + "/index.html#/");
  const frame = page.frameLocator('iframe[title="录播观看"]');
  await frame.getByRole("button", { name: "确认", exact: true }).waitFor();
  await frame.getByPlaceholder("密钥", { exact: true }).fill("wrong-key");
  await frame.getByRole("button", { name: "确认", exact: true }).click();
  await frame.getByText("密钥错误", { exact: true }).waitFor();
  await frame.getByPlaceholder("密钥", { exact: true }).fill(secret);
  await frame.getByRole("button", { name: "确认", exact: true }).click();
  await frame
    .getByRole("button", { name: "我已严肃阅读(〃∀〃)", exact: true })
    .click();
  await frame
    .getByRole("button", { name: "查看 插件测试主播 的录播日历", exact: true })
    .waitFor();
  assert((await page.locator("iframe").boundingBox()).height >= 800);
  await frame
    .getByRole("button", { name: "查看 插件测试主播 的录播日历", exact: true })
    .scrollIntoViewIfNeeded();
  await page.waitForTimeout(200);
  assert.equal(
    await page.evaluate(() => localStorage.getItem("key")),
    "NAS-HOST-SENTINEL",
  );
  assert.equal(
    await page.evaluate(() => localStorage.getItem("bililivewatch:12345:key")),
    secret,
  );
  await page.screenshot({
    path: path.join(root, "mobile-home.png"),
    fullPage: true,
  });
  await frame
    .getByRole("button", { name: "切换观看页主题", exact: true })
    .click();
  await frame.getByText("深色", { exact: true }).click();
  const inner = page.frames().find((f) => f.url().includes("/web/index.html"));
  await inner.waitForFunction(
    () => document.documentElement.dataset.theme === "dark",
  );
  await frame
    .getByRole("button", { name: "查看 插件测试主播 的录播日历", exact: true })
    .click();
  await frame.getByRole("button", { name: /2026-10-15，1 场录像/ }).click();
  await frame.locator(".day-sessions .session-entry").click();
  await inner.waitForFunction(
    () => {
      const v = document.querySelector("video");
      return v && !v.paused && v.currentTime >= 7;
    },
    null,
    { timeout: 2500 },
  );
  await frame
    .getByRole("button", { name: "播放第 3 段", exact: true })
    .waitFor();
  await page.screenshot({
    path: path.join(root, "mobile-player.png"),
    fullPage: true,
  });
  await inner.evaluate(() => {
    window.__originalVideo = document.querySelector("video");
  });
  // A real browser user gesture enters fullscreen; actual media EOF advances.
  await frame.locator(".art-control-fullscreen").click();
  await inner.waitForFunction(() => !!document.fullscreenElement);
  await inner.evaluate(() => {
    const v = document.querySelector("video");
    v.currentTime = v.duration - 0.2;
    void v.play();
  });
  await inner.waitForFunction(
    () =>
      document
        .querySelector(".episode.selected .episode-number")
        ?.textContent?.trim() === "2",
  );
  await inner.waitForFunction(() => {
    const v = document.querySelector("video");
    return v && !v.paused && v.currentTime > 0;
  });
  assert(
    await inner.evaluate(
      () =>
        !!document.fullscreenElement &&
        document.querySelector("video") === window.__originalVideo,
    ),
  );
  assert(
    (await (await api("/watch-history/" + recordWatchKey(records[0]))).json())
      .completed,
  );
  await inner.evaluate(() => document.exitFullscreen());
  await inner.evaluate(() => {
    const v = document.querySelector("video");
    v.currentTime = 5;
    v.pause();
  });
  await frame.getByRole("button", { name: "录播日历", exact: true }).click();
  await page.reload();
  await frame
    .getByRole("button", { name: "查看 插件测试主播 的录播日历", exact: true })
    .waitFor();
  const progress = await (
    await api("/watch-history/" + recordWatchKey(records[1]))
  ).json();
  assert(progress.position >= 5);
  assert.equal(progress.completed, false);
  await frame.getByRole("link", { name: "文件", exact: true }).click();
  await frame.getByText("clip.mp4", { exact: true }).waitFor();
  await frame.getByRole("button", { name: "播放", exact: true }).click();
  await frame.locator("video").waitFor();
  const fileFrame = page
    .frames()
    .find((f) => f.url().includes("/web/index.html"));
  await fileFrame.waitForFunction(
    () => document.querySelector("video")?.readyState >= 1,
  );
  const playingId = await fileFrame.evaluate(() =>
    document.querySelector("video").currentSrc.split("/").pop(),
  );
  const playingState = await (
    await api("/watch-history/resolve", "POST", { videoId: playingId })
  ).json();
  await fileFrame.evaluate(async () => {
    const v = document.querySelector("video");
    await v.play();
    v.currentTime = 4;
  });
  await page.evaluate(() => window.dispatchEvent(new Event("unmount")));
  assert.equal(await page.locator("iframe").count(), 0);
  let flushed = false;
  for (let i = 0; i < 20; i++) {
    if (
      (await (await api("/watch-history/" + playingState.key)).json())
        .position >= 4
    ) {
      flushed = true;
      break;
    }
    await page.waitForTimeout(100);
  }
  assert(
    flushed,
    "plugin close must flush progress before removing its iframe",
  );
  // The NAS may keep the host JS realm when a plugin closes and opens again.
  await page.evaluate(() => {
    const entry = document.createElement("script");
    entry.src = "/plugin/12345/bililivewatch/shell.js?v=0.2.3";
    document.body.appendChild(entry);
  });
  await frame.getByRole("button", { name: "电脑版", exact: true }).click();
  await frame.locator(".mobile-menu-trigger").click();
  await frame.getByText("登出", { exact: true }).click();
  await frame.getByRole("button", { name: "确认", exact: true }).waitFor();
  assert.equal(
    await page.evaluate(() => localStorage.getItem("bililivewatch:12345:key")),
    "",
  );
  assert.equal(
    await page.evaluate(() => localStorage.getItem("key")),
    "NAS-HOST-SENTINEL",
  );
  assert(
    requests
      .filter((u) => u.startsWith(origin) && u.includes("/api/"))
      .every((u) => u.startsWith(origin + prefix + "/api/")),
  );
  assert.equal(errors.length, 0, errors.join("\n"));
  console.log(
    "PASS iframe mobile: login, host storage isolation, theme, calendar, resume7s, real-ended fullscreen autoplay, progress, file playback, close/save/reopen, logout, same-origin API URLs",
  );
  await ctx.close();
  await require("./fullscreen.cjs")(browser, origin, prefix, secret, root);
  const desktop = await browser.newContext({
    viewport: { width: 1280, height: 800 },
  });
  await desktop.addCookies([
    { name: "nas_test", value: "local-auth", url: origin },
  ]);
  await desktop.addInitScript(
    ({ key }) => {
      localStorage.setItem("bililivewatch:12345:key", key);
      localStorage.setItem("bililivewatch:12345:api", "/api");
      localStorage.setItem(
        "bililivewatch:12345:changelog",
        JSON.stringify({ "3.22.2": true }),
      );
    },
    { key: secret },
  );
  const pc = await desktop.newPage();
  await pc.goto(origin + prefix + "/index.html#/");
  const desktopFrame = pc.frameLocator("iframe");
  await desktopFrame
    .getByRole("button", { name: "查看 插件测试主播 的录播日历", exact: true })
    .waitFor();
  assert(
    await pc
      .frames()
      .find((item) => item.url().includes("/web/index.html"))
      .evaluate(() => !window.__bililiveNasFullscreen),
  );
  assert((await pc.locator("iframe").boundingBox()).height >= 760);
  await pc.waitForTimeout(200);
  await pc.screenshot({
    path: path.join(root, "desktop-home.png"),
    fullPage: true,
  });
  assert(
    await pc
      .frames()
      .find((f) => f.url().includes("/web/index.html"))
      .evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1),
  );
  await pc.evaluate(() => {
    const host = document.createElement("micro-app");
    host.style.cssText = "display:block;height:520px";
    document.body.append(host);
    host.append(document.getElementById("bililivewatch-shell"));
    window.dispatchEvent(new Event("resize"));
  });
  assert.equal(
    Math.round((await pc.locator("iframe").boundingBox()).height),
    520,
  );
  await desktop.close();
  const readonly = new Database(path.join(root, "data/app.db"), {
    readonly: true,
  });
  assert.deepEqual(
    readonly.prepare("SELECT * FROM record_history").all(),
    records,
  );
  assert.deepEqual(
    readonly.prepare("SELECT sql FROM sqlite_master ORDER BY name").all(),
    schema,
  );
  readonly.close();
  await stop(backend);
  launch();
  await ready("http://127.0.0.1:18041/common/version", {
    headers: { Authorization: secret },
  });
  assert(
    (await (await api("/watch-history/" + recordWatchKey(records[0]))).json())
      .completed,
  );
  assert(
    (await (await api("/watch-history/" + recordWatchKey(records[1]))).json())
      .position >= 5,
  );
  console.log(
    "PASS desktop iframe, unchanged legacy rows/schema, backend restart persistence",
  );
  fs.writeFileSync(
    path.join(root, "result.json"),
    JSON.stringify(
      {
        status: "passed",
        completedAt: new Date().toISOString(),
        realNginx: true,
        realBackend: true,
        realChromium: true,
        realNas: false,
        mobileExternalAccess: false,
      },
      null,
      2,
    ),
  );
}
main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (browser) await browser.close();
    for (const proc of children.reverse()) await stop(proc);
  });
