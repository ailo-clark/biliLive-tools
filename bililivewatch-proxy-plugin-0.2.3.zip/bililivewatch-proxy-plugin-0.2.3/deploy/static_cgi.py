#!/usr/bin/python3
"""NAS-authenticated entry: local shell plus live Docker HTML/JS adaptation."""
import http.client
from http import HTTPStatus
import json
import mimetypes
import os
from pathlib import Path
import re
import sys

MAX_WEB_BYTES = 32 * 1024 * 1024


def error(output, status):
    phrase = HTTPStatus(status).phrase
    body = phrase.encode("ascii")
    output.write(f"Status: {status} {phrase}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {len(body)}\r\nCache-Control: no-store\r\n\r\n".encode())
    if os.environ.get("REQUEST_METHOD", "GET") != "HEAD":
        output.write(body)


def live_web(relative, config, output):
    """Only GET/HEAD HTML/JS; API and video never pass through Python."""
    if os.environ.get("REQUEST_METHOD", "GET") not in ("GET", "HEAD"):
        error(output, 405)
        return
    name = relative[len("web/"):] or "index.html"
    if (name != "index.html" and not name.endswith((".js", ".mjs"))) or not re.fullmatch(r"[A-Za-z0-9_./-]+", name):
        error(output, 404)
        return
    connection = None
    try:
        uid, port = str(config["uid"]), int(config["port"])
        if not re.fullmatch(r"[1-9][0-9]{0,19}", uid) or not 1 <= port <= 65535:
            raise ValueError("invalid local proxy config")
        # Fixed loopback host, no environment proxy or redirect following.
        # Never forward NAS cookies or login secrets to Docker's static UI.
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=15)
        connection.request("GET", "/" + name, headers={"Accept-Encoding": "identity"})
        response = connection.getresponse()
        if response.status != 200:
            error(output, 404 if response.status == 404 else 502)
            return
        mime = response.getheader("Content-Type", "").split(";", 1)[0].strip().lower()
        is_html = name == "index.html"
        if mime not in ({"text/html"} if is_html else {"application/javascript", "text/javascript"}):
            raise ValueError("unexpected Docker content type")
        if response.getheader("Content-Encoding", "identity").lower() not in ("", "identity"):
            raise ValueError("Docker did not return uncompressed text")
        body = response.read(MAX_WEB_BYTES + 1)
        if len(body) > MAX_WEB_BYTES:
            raise ValueError("Docker web response too large")
        public = f"/plugin/{uid}/bililivewatch"
        if is_html:
            injection = (f'<script src="{public}/bridge.js?v=0.2.3"></script>'
                         f'<script src="{public}/fullscreen.js?v=0.2.3"></script>').encode()
            body, count = re.subn(b"<head>", lambda m: m.group() + injection, body, count=1, flags=re.IGNORECASE)
            if count != 1 or b'id="app"' not in body:
                raise ValueError("unexpected Docker entry")
        else:
            for quote in (b'"', b"'", b"`"):
                body = body.replace(quote + b"/api" + quote, quote + public.encode() + b"/api" + quote)
        output.write(f"Content-Type: {mime}; charset=utf-8\r\nContent-Length: {len(body)}\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n\r\n".encode())
        if os.environ.get("REQUEST_METHOD", "GET") != "HEAD":
            output.write(body)
    except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException):
        error(output, 502)
    finally:
        if connection is not None:
            connection.close()


def serve(root, requested, output, proxy=None):
    root = Path(root).resolve()
    try:
        candidate = Path(requested).resolve()
        relative = candidate.relative_to(root).as_posix()
        if (relative == "web" or relative.startswith("web/")) and proxy is not None:
            live_web(relative, proxy, output)
            return
        target = Path(requested).resolve(strict=True)
        target.relative_to(root)
        if not target.is_file() or target.suffix not in {".html", ".js", ".css", ".json", ".png", ".jpg", ".jpeg", ".svg", ".ico", ".woff", ".woff2", ".ttf", ".wasm"}:
            raise ValueError("not a UI file")
    except (ValueError, OSError):
        output.write(b"Status: 404 Not Found\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nNot found")
        return
    mime = {".js": "application/javascript", ".wasm": "application/wasm"}.get(target.suffix) or mimetypes.guess_type(target)[0] or "application/octet-stream"
    # index/shell use no-cache; hashed Vite assets can be cached privately.
    cache = "private, max-age=86400" if "assets" in target.relative_to(root).parts else "no-cache"
    output.write(f"Content-Type: {mime}\r\nContent-Length: {target.stat().st_size}\r\nCache-Control: {cache}\r\nX-Content-Type-Options: nosniff\r\n\r\n".encode())
    if os.environ.get("REQUEST_METHOD", "GET") == "HEAD":
        return
    with target.open("rb") as stream:
        while data := stream.read(64 * 1024):
            output.write(data)


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    try:
        config = json.loads((root.parent / "proxy.json").read_text())
    except (OSError, ValueError):
        config = {}
    serve(root, os.environ.get("FILE_REQ", ""), sys.stdout.buffer, proxy=config)
